
#!/usr/bin/env bash
set -e
echo "Uninstalling geo-service..."
sudo rm -rf /opt/geo-service
echo "Done."
        